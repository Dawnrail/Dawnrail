# Dawnrail site — changelog

## Unreleased

### Added
- Brand mark: a bare gold capital "D" (Cormorant Garamond), added back
  next to the "Dawnrail" wordmark in the nav and footer, separated by a
  hairline divider so it doesn't misread as a doubled letter
  ("DDawnrail"). Footer version uses the dimmer accent to match the
  existing footer-is-quieter convention.
- Real favicon (`favicon.svg`): same D mark on a dark rounded-square
  background, using a system serif fallback rather than Cormorant
  Garamond for reliability in favicon rendering contexts.

### Changed
- Hero headline: "SSH, SFTP, and serial. One terminal." → "SSH, SFTP, and serial. A cross-platform terminal."
- Removed every em dash from visible copy and the source comments, replaced with commas, a colon, or a middle dot depending on context:
  - Page title: "Specter — SSH..." → "Specter: SSH..."
  - Windows download subtitle: "Installer (.exe) — recommended" → "Installer (.exe), recommended"
  - Terminal mockup title bar: "SW-ACCESS-04 — ssh" → "SW-ACCESS-04 · ssh"
  - Terminal mockup warning link: "I understand the risk — trust anyway" → "I understand the risk, trust anyway"

### Removed
- The "Why" philosophy/mission-statement section (the standalone blockquote: "Dawnrail is built by a network engineer, for the terminal they actually use during a real SSH session, not a roadmap slide.")
- The "About" link from both the nav bar and the footer, since it pointed at the now-removed section
- Associated dead CSS (`.philosophy`, `.philosophy-inner`, `.philosophy blockquote`, `.philosophy-attr`, and the related mobile breakpoint rule)

### Kept as-is
- The "Why Specter" feature-grid section (host-key checks, cross-platform, personalization), confirmed this stays, it's a different section from the one that was removed

---

## Earlier passes (for reference)

- Design direction: dark monochrome (grayscale + one neutral highlight) → gold accent added back in (`#D4A855`, matching the live site) → softened significantly: Cormorant Garamond serif replacing the bold condensed sans, ghost-style outline buttons instead of solid fills, paler dustier gold (`#C9A66B`), thinner rail-line motif with a slower drifting glow
- Copy pass: dropped comparative claims about other terminal clients ("doesn't lie to you," "safety checks most clients skip," etc.) in favor of plain, factual feature descriptions, closer to how MobaXterm describes itself
- Logo mark removed from nav and footer, wordmark only
- Skald removed from the page entirely, Specter-only launch per current IP disclosure status (SKA-23)
- Kept from the original live page: the three direct download links (Windows installer, macOS universal, Linux tar.gz) and the host-key-change warning terminal mockup content, both restyled into the new system
