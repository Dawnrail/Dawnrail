# Copilot instructions — Dawnrail site

This repo is a single self-contained `index.html` (plain HTML/CSS, no
build step, no framework, no JS beyond a couple of inline listeners).
Fonts load from Google Fonts via a `<link>` tag. There is nothing to
compile, bundle, or install, edits go straight into `index.html`.

Follow these conventions on every change. If a request conflicts with
one of these, point out the conflict rather than silently overriding
it.

## Design system

**Colors** (CSS custom properties in `:root`, always use the variable,
never a raw hex):
- `--bg` / `--bg-alt` / `--bg-alt-2` — near-black, neutral, no blue or
  brown tint
- `--border` / `--border-soft` — subtle dividers
- `--text` / `--text-muted` / `--text-dim` — three levels of gray
- `--accent` (`#C9A66B`) — a pale, dusty "candlelight" gold. Deliberately
  desaturated, not a bright/saturated gold. This is the only color
  accent on the page.
- `--accent-dim` (`#7A6644`) — the muted variant, used for
  less-emphasized/secondary accent moments

**Typography**, three families, each with one job:
- `'Cormorant Garamond', serif` — all headlines (h1, h2, h3, the
  wordmark). Light/regular weight (400–600), never bold, never
  uppercase. This is deliberate: the product is called Specter, the
  whole site should read as quiet and a little ghostly, not bold or
  loud. Do not swap in a heavier sans-serif display face for headlines.
- `'Inter', sans-serif` — body copy
- `'JetBrains Mono', monospace` — labels, eyebrows, status badges, the
  terminal mockup, anything code-like

**Buttons**: ghost/outline style only — transparent background, a
1px border in `--accent-dim` that brightens to `--accent` on hover,
with a soft `box-shadow` glow, not a hard color swap or a `transform`
jump. Never a solid filled button. This is intentional, matches the
"ghost" theme.

**Motion**: slow and soft. The rail-line pulse animation runs ~4.4s
with `ease-in-out`, not a fast linear dash. The status dot pulses over
~3.2s. If adding new motion, keep it slow and always wrap it in
`@media (prefers-reduced-motion: no-preference)` with a matching
`reduce` block that disables or hides it.

**Layout**: CSS Grid and flexbox `gap` are used throughout. Every
`gap` usage has a matching `@supports not (gap: 1px)` fallback near
the end of the stylesheet using margins instead. The `.feature-grid`
has an `@supports not (display: grid)` fallback too. If you add a new
flex/grid container with `gap`, add its fallback in the same place.

## Copy / writing rules

- **No em dashes anywhere** — not in headlines, body copy, button
  labels, or code comments. Use a comma, colon, period, or a middle
  dot (`·`) depending on context.
- **No comparative or superlative claims.** Do not write things like
  "the only terminal that…", "unlike other tools…", "the safety
  checks most clients skip…", or generalizations about "most
  infrastructure tools"/"the industry". Describe what Specter actually
  does, plainly, the way MobaXterm's own site does ("an enhanced
  terminal app that brings X to Y"), not what's wrong with competitors.
- Keep sentences concrete and factual. If a feature claim can't be
  verified against what's actually shipped, don't add it.

## Content constraints

- **Specter-only.** Do not add any mention of Skald (Dawnrail's other,
  unannounced product) anywhere on this page, copy, meta tags, alt
  text, or comments. Skald's public disclosure is gated on an
  unresolved IP/legal review; a mention here would be a real problem,
  not just a style issue.
- **Brand mark**: a bare capital "D" in Cormorant Garamond, gold
  (`--accent` in the nav, `--accent-dim` in the footer), separated from
  the "Dawnrail" wordmark by a 1px vertical divider (`border-right` on
  `.brand-mark`). That divider is load-bearing, don't remove it: the
  mark and the wordmark both start with "D", without a visible
  separator between them it misreads as a typo ("DDawnrail"). The
  favicon (`favicon.svg`) uses the same letter on a dark rounded-square
  background, with a system serif fallback stack rather than Cormorant
  Garamond, since favicon rendering contexts can't reliably load
  Google Fonts.
- **Don't alter the three download URLs** in the `.downloads` section
  (Windows `.exe`, macOS `.zip`, Linux `.tar.gz`) — they point at real
  GitHub release assets.
- **Don't alter the terminal mockup content** (the host-key-changed
  warning) without being asked, it's deliberately kept close to the
  original, tested copy from the previous version of this page.

## Structure notes

- Section IDs (`#download`, `#features`) are used by the nav's anchor
  links, keep them in sync if you rename a section.
- The rail-line SVG in the hero (`.switch-wrap`) is a single track, not
  a fork/switch. It used to be a two-branch "switch" shape representing
  two products (Specter + Skald); it was simplified to one line when
  Skald was pulled from the page, since a fork shape would visually
  claim two visible product lines when there's only one. Don't restore
  the fork shape unless Skald is being reintroduced to the page at the
  same time.
- There's a `CHANGELOG.md` in this repo. Add an entry there for any
  non-trivial change (copy changes, section adds/removes, design
  system changes) — don't just edit `index.html` silently.
